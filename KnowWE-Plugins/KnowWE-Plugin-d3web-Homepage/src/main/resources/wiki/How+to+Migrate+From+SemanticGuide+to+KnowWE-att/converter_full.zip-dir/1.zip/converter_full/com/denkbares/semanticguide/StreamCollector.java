/*
 * Copyright (C) 2013 denkbares GmbH
 *
 * This is free software; you can redistribute it and/or modify it under the
 * terms of the GNU Lesser General Public License as published by the Free
 * Software Foundation; either version 3 of the License, or (at your option) any
 * later version.
 *
 * This software is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
 * FOR A PARTICULAR PURPOSE. See the GNU Lesser General Public License for more
 * details.
 *
 * You should have received a copy of the GNU Lesser General Public License
 * along with this software; if not, write to the Free Software Foundation,
 * Inc., 51 Franklin St, Fifth Floor, Boston, MA 02110-1301 USA, or see the FSF
 * site: http://www.fsf.org.
 */

package com.denkbares.semanticguide;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.OutputStream;
import java.io.PrintStream;

/**
 * @author Volker Belli (denkbares GmbH)
 * @created 13.08.14.
 */
public class StreamCollector {

	private final ByteArrayOutputStream notepad = new ByteArrayOutputStream();

	public StreamCollector() {
	}

	public void infectStdOut() {
		System.setOut(listen(System.out));
		System.setErr(listen(System.err));
	}

	public PrintStream listen(final OutputStream out) {
		return new PrintStream(new OutputStream() {
			@Override
			public void write(int b) throws IOException {
				notepad.write(b);
				out.write(b);
			}

			@Override
			public void write(byte[] b) throws IOException {
				notepad.write(b);
				out.write(b);
			}

			@Override
			public void write(byte[] b, int off, int len) throws IOException {
				notepad.write(b, off, len);
				out.write(b, off, len);
			}
		}, true);
	}

	public void writeWikiPage(PrintStream page) throws IOException {
		page.write("!!! Converter Console Log\n".getBytes());
		page.write("{{{\n".getBytes());
		page.write(notepad.toByteArray());
		page.write("\n}}}\n".getBytes());
	}
}
