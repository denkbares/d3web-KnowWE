package com.denkbares.semanticguide;/*
 * Copyright (C) 2013 denkbares GmbH
 *
 * This is free software; you can redistribute it and/or modify it under the
 * terms of the GNU Lesser General Public License as published by the Free
 * Software Foundation; either version 3 of the License, or (at your option) any
 * later version.
 *
 * This software is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
 * FOR A PARTICULAR PURPOSE. See the GNU Lesser General Public License for more
 * details.
 *
 * You should have received a copy of the GNU Lesser General Public License
 * along with this software; if not, write to the Free Software Foundation,
 * Inc., 51 Franklin St, Fifth Floor, Boston, MA 02110-1301 USA, or see the FSF
 * site: http://www.fsf.org.
 */

import java.awt.*;
import java.io.File;
import java.io.IOException;
import java.text.ParseException;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import de.d3web.collections.DefaultMultiMap;
import de.d3web.collections.Matrix;
import de.d3web.collections.MultiMap;
import de.d3web.collections.MultiMaps;
import de.d3web.strings.Strings;
import de.d3web.utils.Files;
import de.d3web.utils.Pair;
import de.knowwe.export.TurtleWriter;

/**
 * @author Volker Belli (denkbares GmbH)
 * @created 01.07.14.
 */
public class DomainParser {

	private static final String TEXT = "\"(?:[^\"\\\\]|\\\\.)*\"";
	private static final String NUMBER = "\\d+(?:\\.\\d+)?";
	private static final String DATE = "\"\\d\\d\\d\\d-\\d\\d-\\d\\dT\\d\\d:\\d\\d:\\d\\d.\\d{0,3}\\+\\d\\d:\\d\\d\"\\^\\^_dateTime";
	private static final String NULL = "null";

	private static final String URI = "<[^>]*>";
	private static final String OBJECT = "(?:" + TEXT + "|" + URI + ")";
	private static final String ATTRIBUTE = "(\\w*)(?:\\((\"[^\"]*\"|null)\\))?";
	private static final String VALUE = "(?:" + TEXT + "|" + URI + "|" + NUMBER + "|" + DATE + "|" + NULL + ")";

	private static final String DEFINITION = "^\\s*(" + OBJECT + "):(?:cat#)?(.*)\\.\\s*$";
	private static final String PROPERTY = "^\\s*(" + OBJECT + ")\\[(?:prp#|_)" + ATTRIBUTE + "->(" + VALUE + ")\\]";

	@SuppressWarnings("unchecked")
	private static final Pair<String, String>[] attributeMappings = new Pair[] {
			new Pair("representation", "skos:prefLabel")
	};

	public static class Instance implements TurtleWriter.Value {
		private final String uri;
		private final String type;
		private final MultiMap<String, Object> attributes = new DefaultMultiMap<>();

		public Instance(String uri, String type) {
			this.uri = uri;
			this.type = type;
		}

		public String getUri() {
			return uri;
		}

		public String getType() {
			return type;
		}

		public MultiMap<String, Object> getAttributes() {
			return MultiMaps.unmodifiableMultiMap(attributes);
		}

		public Object getValue(String attribute) {
			Collection<Object> values = getValues(attribute);
			if (values == null || values.isEmpty()) return null;
			return values.iterator().next();
		}

		public Collection<Object> getValues(String attribute) {
			return attributes.getValues(attribute);
		}

		public <T> Collection<T> getValues(String attribute, Class<T> clazz) {
			Set<Object> values = attributes.getValues(attribute);
			List<T> result = new ArrayList<>(values.size());
			for (Object value : values) {
				if (clazz.isInstance(value)) result.add(clazz.cast(value));
			}
			return result;
		}

		public Object addValue(String attribute, Object value) {
			return attributes.put(attribute, value);
		}

		public String getPrefLabel() {
			Object label = getValue("skos:prefLabel");
			if (label instanceof TurtleWriter.Text) {
				return ((TurtleWriter.Text) label).getText();
			}
			return null;
		}

		public String getPrefLabelOrUri() {
			String label = getPrefLabel();
			return (label == null) ? getUri() : label;
		}

		@Override
		public String toTurtle() {
			return getUri();
		}

		@Override
		public String toString() {
			return getUri();
		}
	}

	private final Map<String, Instance> objects = new LinkedHashMap<>();

	public DomainParser() {
	}

	public DomainParser(File source) throws IOException {
		this();
		parse(source);
	}

	public Collection<Instance> getInstances() {
		return Collections.unmodifiableCollection(objects.values());
	}

	public Instance getInstance(String id) {
		return objects.get(id);
	}

	public void addPositions(File file) throws IOException {
		Matrix<String> cells = Files.getCSVCells(file, "\t");
		for (int row = 1; row < cells.getRowSize(); row++) {
			String id = cells.get(row, 0);
			Instance instance = getInstance(id);
			if (instance != null) {
				Integer x = Integer.parseInt(cells.get(row, 1));
				Integer y = Integer.parseInt(cells.get(row, 2));
				instance.addValue("position", new Point(x, y));
			}
		}
	}

	public void addNames(File file) throws IOException {
		Matrix<String> cells = Files.getCSVCells(file, "\t");
		for (int row = 1; row < cells.getRowSize(); row++) {
			String id = cells.get(row, 0);
			Instance instance = getInstance(id);
			if (instance != null) {
				String text = cells.get(row, 1).replace('"', '\'');
				instance.addValue("skos:prefLabel", new TurtleWriter.Text(text));
			}
		}
	}

	public void parse(File source) throws IOException {
		List<String> lines = Files.getLines(source);
		for (String line : lines) {
			parseLine(line);
		}
	}

	public static void main(String[] args) throws IOException {
		Matcher matcher = Pattern.compile(DATE).matcher("\"2014-06-17T11:27:03.607+02:00\"^^_dateTime");
		System.out.println(matcher.find());

		matcher = Pattern.compile(VALUE).matcher("\"2014-06-17T11:27:03.607+02:00\"^^_dateTime");
		System.out.println(matcher.find());

		matcher = Pattern.compile(PROPERTY).matcher("<sg:attachment:100>[prp#DateCreated(\"\")->\"2014-06-17T11:27:03.607+02:00\"^^_dateTime].");
		System.out.println(matcher.find());
	}

	private void parseLine(String line) throws IOException {
		Pattern REGEX_DEF = Pattern.compile(DEFINITION);
		Pattern REGEX_PROP = Pattern.compile(PROPERTY);

		Matcher matcher = REGEX_DEF.matcher(line);
		if (matcher.find()) {
			String object = matcher.group(1);
			String type = matcher.group(2);

			// ignore languages, not required by us
			if (type.equals("Language")) return;

			Instance instance = new Instance(getUriFromId(object), type);
			objects.put(object, instance);
			return;
		}

		matcher = REGEX_PROP.matcher(line);
		if (matcher.find()) {
			String object = matcher.group(1);
			String attribute = matcher.group(2);
			Object value = parseValue(matcher.group(4), matcher.group(3));
			// do not add null references
			if (value == null) return;
			// map some attributes
			for (Pair<String, String> mapping : attributeMappings) {
				if (Strings.equals(attribute, mapping.getA())) {
					attribute = mapping.getB();
					break;
				}
			}
			objects.get(object).addValue(attribute, value);
			return;
		}

		// try some lines patterns to ignore
		if (Strings.isBlank(line)) return;
		if (line.startsWith("//")) return;
		if (line.startsWith(":-")) return;
		if (line.startsWith("SearchTerm[")) return;
		if (line.startsWith("\"en\"[prp#default].")) return;
		// module declaration
		if (line.trim().equals("@module {")) return;
		if (line.startsWith("  info[")) return;
		if (line.trim().equals("}.")) return;

		// otherwise warn about missed information
		System.err.println("ignored content: "+line);
	}

	private String getUriFromId(String id) {
		Matcher matcher = Pattern.compile("<(\\w*):(\\w*):(\\w*)>").matcher(id);
		if (!matcher.find()) {
			throw new IllegalStateException();
		}
		return matcher.group(1) + ":" + matcher.group(2) + "_" + matcher.group(3);
	}

	private Object parseValue(String value, String parameter) throws IOException {
		if (value.matches(TEXT)) {
			String text = Strings.unquote(value).replace('"', '\'')
					.replace("\\n", "\n").replace("\\r", "\r").replace("\\t", "\t")
					.replace("\\b", "\b").replace("\\f", "\f");
			if (Strings.isBlank(parameter)) {
				return new TurtleWriter.Text(text);
			}
			else {
				return new TurtleWriter.Text(text, Strings.unquote(parameter));
			}
		}
		if (value.matches(NUMBER)) {
			if (value.contains(".")) {
				return new Float(value);
			}
			else {
				return new Integer(value);
			}
		}
		if (value.matches(NULL)) {
			return null;
		}
		if (value.matches(DATE)) {
			try {
				return new TurtleWriter.Date(Strings.unquote(value.replace("^^_dateTime", "")));
			}
			catch (ParseException e) {
				throw new IOException("unrecognized date format: " + value);
			}
		}
		if (value.matches(URI)) {
			Instance instance = objects.get(value);
			if (instance == null) {
				System.err.printf("instance %s is referenced, but not defined%n", value);
			}
			return instance;
		}
		throw new IllegalStateException();
	}

}
