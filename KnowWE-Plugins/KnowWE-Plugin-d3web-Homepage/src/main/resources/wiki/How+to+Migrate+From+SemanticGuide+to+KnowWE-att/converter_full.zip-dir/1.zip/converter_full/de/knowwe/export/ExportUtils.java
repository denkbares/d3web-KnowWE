/*
 * Copyright (C) 2013 denkbares GmbH
 *
 * This is free software; you can redistribute it and/or modify it under the
 * terms of the GNU Lesser General Public License as published by the Free
 * Software Foundation; either version 3 of the License, or (at your option) any
 * later version.
 *
 * This software is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
 * FOR A PARTICULAR PURPOSE. See the GNU Lesser General Public License for more
 * details.
 *
 * You should have received a copy of the GNU Lesser General Public License
 * along with this software; if not, write to the Free Software Foundation,
 * Inc., 51 Franklin St, Fifth Floor, Boston, MA 02110-1301 USA, or see the FSF
 * site: http://www.fsf.org.
 */
package de.knowwe.export;

/**
 * @author Sebastian Furth (denkbares GmbH)
 * @created 18.02.14
 */
public class ExportUtils {

	public static String toUriName(String displayText) {
		String[] toRemove = { ",", "'", "\\(", "\\)" };
		String[] toReplaceByUnderscore = { "\\s+", "\\.", "/", "/" };

		for (String stringToUnderscore : toReplaceByUnderscore) {
			displayText = displayText.replaceAll(stringToUnderscore, "_");
		}

		for (String stringToRemove : toRemove) {
			displayText = displayText.replaceAll(stringToRemove, "");
		}

		String name = replaceUmlauts(displayText);

		// cut a trailing underscore
		if (name.endsWith("_")) {
			name = name.substring(0, name.length() - 1);
		}
		return name;
	}

	public static String replaceUmlauts(String string) {
		string = string.replaceAll("ö", "oe");
		string = string.replaceAll("ä", "ae");
		string = string.replaceAll("ü", "ue");
		string = string.replaceAll("Ö", "Oe");
		string = string.replaceAll("Ä", "Ae");
		string = string.replaceAll("Ü", "Ue");
		string = string.replaceAll("ß", "ss");
		return string;
	}


}
