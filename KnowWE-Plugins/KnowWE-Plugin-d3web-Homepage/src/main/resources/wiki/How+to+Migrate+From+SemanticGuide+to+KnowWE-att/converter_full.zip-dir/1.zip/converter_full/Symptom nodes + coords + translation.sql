SELECT 
	[sgdesigner].[dbo].[node_position].x_coord, [sgdesigner].[dbo].[node_position].y_coord,
	[sgdesigner].[dbo].[symptom_node].id, [sgdesigner].[dbo].[translation].value0
 FROM [sgdesigner].[dbo].[symptom_node]
	JOIN [sgdesigner].[dbo].[node_position]	
	ON [sgdesigner].[dbo].[node_position].id = [sgdesigner].[dbo].[symptom_node].position_id
	JOIN [sgdesigner].[dbo].[symptom]
	ON [sgdesigner].[dbo].[symptom].id = [sgdesigner].[dbo].[symptom_node].symptom_id
	JOIN [sgdesigner].[dbo].[translation]
	ON [sgdesigner].[dbo].[translation].id = [sgdesigner].[dbo].[symptom].NAME_TRANSLATION_ID
ORDER BY [sgdesigner].[dbo].[symptom_node].id ASC