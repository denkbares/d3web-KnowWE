package de.knowwe.export;

import java.io.PrintStream;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Arrays;
import java.util.Collection;
import java.util.LinkedList;
import java.util.List;
import java.util.Locale;

import de.d3web.strings.Strings;
import de.d3web.utils.Tuple;

public class TurtleWriter {

	public interface URIObject {

		/**
		 * Returns the uri to be used for this kb object
		 *
		 * @return the object's uri
		 * @created 07.11.2013
		 */
		public String getURI();
	}

	public interface Value {
		String toTurtle();
	}

	public static class Text implements Value {
		private final String text;
		private final Locale locale;

		public Text(String text) {
			this(text, (Locale) null);
		}

		public Text(String text, String language) {
			this(text, new Locale(language));
		}

		public Text(String text, Locale locale) {
			this.text = text;
			this.locale = locale;
		}

		public Locale getLocale() {
			return locale;
		}

		public String getText() {
			return text;
		}

		@Override
		public String toTurtle() {
			return (locale == null) ? Strings.quote(text)
					: Strings.quote(text) + "@" + locale.getLanguage();
		}

		@Override
		public String toString() {
			return toTurtle();
		}

		public boolean hasLocale() {
			return locale != null;
		}
	}

	public static class Date implements Value {

		private static final SimpleDateFormat DATE_FORMAT = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss.SSSXXX");
		private final java.util.Date date;

		public Date(String date) throws ParseException {
			this.date = DATE_FORMAT.parse(date);
		}

		public Date(java.util.Date date) {
			this.date = date;
		}

		@Override
		public String toTurtle() {
			return Strings.quote(DATE_FORMAT.format(date))+"^^_dateTime";
		}
	}

	private static enum State {
		init, defined, open, closed
	}

	private static final int MAX_LINE_LENGTH = 120;

	private final PrintStream out;
	private final String defaultTypePredicate;
	private State state = State.init;

	private static final String markupKey = "turtle";

	public TurtleWriter(PrintStream out) {
		this(out, "ssc:type");
	}

	public TurtleWriter(PrintStream out, String defaultTypePredicate) {
		this.out = out;
		this.defaultTypePredicate = defaultTypePredicate;
	}

	public void define(String uri, String type) {
		define(uri, defaultTypePredicate, type);
	}

	public void define(String uri, String typePredicate, String type) {
		close();
		out.printf("\n%%%%" + markupKey + " \n%s\n", uri);
		state = State.defined;
		if (typePredicate != null && type != null) {
			relations(typePredicate, type);
		}
	}

	public void relations(String relation, String... uriOrLabel) {
		relations(false, relation, uriOrLabel);
	}

	public void relations(boolean forceLineBreak, String relation, String... uriOrLiteral) {
		writeRelations(forceLineBreak, relation, Arrays.asList(uriOrLiteral));
	}

	public void relations(String relation, URIObject... objects) {
		relations(false, relation, objects);
	}

	public void relations(boolean forceLineBreak, String relation, URIObject... objects) {
		writeRelations(forceLineBreak, relation, toURIs(Arrays.asList(objects)));
	}

	public void relations(String relation, Value... objects) {
		relations(false, relation, objects);
	}

	public void relations(boolean forceLineBreak, String relation, Value... objects) {
		relations(forceLineBreak, relation, Arrays.asList(objects));
	}

	public void relations(String relation, Collection<?> objects) {
		relations(false, relation, objects);
	}

	public void relations(boolean forceLineBreak, String relation, Collection<?> objects) {
		writeRelations(forceLineBreak, relation, toTurtle(objects));
	}

	public static String escapeDoubleQuotes(String string) {
		string = string.replaceAll("\"", "\\\"");
		return string.replaceAll("\\\"", "\\\\\"");
	}

	private void writeRelations(boolean forceLineBreak, String relation, Collection<String> urisOrLiterals) {
		if (urisOrLiterals == null) return;
		if (urisOrLiterals.isEmpty()) return;
		if (state == State.init || state == State.closed) {
			throw new IllegalStateException("define object before relations");
		}
		if (state == State.open) out.println(";");
		state = State.open;
		out.printf("\n  %s\n    ", relation);
		int lineLen = 4;
		boolean firstObject = true;
		for (String object : urisOrLiterals) {
			if (!firstObject) {
				out.print(", ");
				lineLen += 2;
				if (forceLineBreak || (lineLen > 4 && lineLen + object.length() > MAX_LINE_LENGTH)) {
					out.print("\n    ");
					lineLen = 4;
				}
			}
			firstObject = false;
			out.print(object);
			lineLen += object.length();
		}
	}

	public void close() {
		if (state == State.closed) return;
		if (state == State.open) {
			out.println(".");
			out.println("%");
		}
		state = State.closed;
	}

	public List<String> toURIs(Collection<? extends URIObject> objects) {
		List<String> uris = new LinkedList<String>();
		for (URIObject object : objects) {
			String uri = object.getURI();
			String result = quoteSuffixIfNecessary(uri);
			uris.add(result);
		}
		return uris;
	}

	public List<String> toTurtle(Collection<?> objects) {
		List<String> result = new LinkedList<String>();
		for (Object object : objects) {
			if (object instanceof Value) {
				result.add(((Value) object).toTurtle());
			}
			else if (object instanceof  URIObject) {
				result.add(quoteSuffixIfNecessary(((URIObject) object).getURI()));
			}
			else if (object instanceof Tuple) {
				result.add("( "+ Strings.concat(" ", ((Tuple) object).asList()) + " )");
			}
			else {
				result.add(String.valueOf(object));
			}
		}
		return result;
	}

	public String quoteSuffixIfNecessary(String uri) {
		return uri.replaceAll("\\.", "_").replaceAll(",", "").replaceAll(";", "");
	}
}
