package de.knowwe.export;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.OutputStream;
import java.io.PrintStream;
import java.util.Collections;
import java.util.HashMap;
import java.util.Map;
import java.util.Properties;
import java.util.Set;

import de.d3web.core.io.progress.ConsoleProgressBarListener;
import de.d3web.core.io.progress.ProgressListener;
import de.d3web.strings.Strings;
import de.d3web.utils.Files;

public class PageCreator {

	public static boolean backupPreviousFiles = false;

	private static class Page {
		private final ByteArrayOutputStream buffer = new ByteArrayOutputStream();
		private final PrintStream printStream = new PrintStream(buffer);

		public boolean write(File file) throws IOException {
			printStream.flush();
			// check if file content has changed
			if (file.exists()) {
				String oldContents = Files.getText(file);
				String newContents = buffer.toString();
				if (oldContents.equals(newContents)) {
					return false;
				}
				else if (backupPreviousFiles) {
					File bakFile = getBakFile(file);
					bakFile.delete();
					boolean renamed = file.renameTo(bakFile);
					if (!renamed) throw new IOException("could not move to '.bak' file: " + file);
				}
			}
			// write new file content to disc
			OutputStream out = new FileOutputStream(file);
			try {
				out.write(buffer.toByteArray());
			}
			finally {
				out.close();
			}
			return true;
		}

		private File getBakFile(File file) throws IOException {
			File bakFile = new File(file.getPath().replaceAll("\\.[\\w\\d]+$", "") + ".bak");
			return bakFile.getCanonicalFile();
		}
	}

	private final File targetFolder;
	private final Map<File, Page> createdFiles = new HashMap<File, Page>();

	public static final String EXPORT_WARNING = "%%warning This page is automatically generated and will be overwritten in the future. Do not edit this page. %%";

	public PageCreator(String targetFolderName) {
		this(new File(targetFolderName));
		if (targetFolderName.isEmpty()) {
			throw new IllegalArgumentException("Target folder name can't be empty!");
		}
	}

	public PageCreator(File targetFolder) {
		this.targetFolder = targetFolder.getAbsoluteFile();
		this.targetFolder.mkdirs();
	}

	public PrintStream createPage(String pageName) throws IOException {
		return createPage(pageName, null);
	}
	public PrintStream createPage(String pageName, boolean suppressExportWarning) throws IOException {
		return createPage(pageName, null, suppressExportWarning);
	}

	public PrintStream createPage(String pageName, String objectCategory) throws IOException {
		return createPage(null, pageName, objectCategory, null);
	}

	public PrintStream createPage(String pageName, String objectCategory, boolean suppressExportWarning) throws IOException {
		return createPage(null, pageName, objectCategory, null, suppressExportWarning);
	}

	public PrintStream createPage(String pagePrefix, String pageName, String objectCategory, String packageName) throws IOException {
		return createPage(pagePrefix, pageName, objectCategory, packageName, false);
	}
	public PrintStream createPage(String pagePrefix, String pageName, String objectCategory, String packageName, boolean suppressExportWarning) throws IOException {
		// create unique file for the page (or exception if not possible)
		if (!Strings.isBlank(pagePrefix)) pageName = pagePrefix + " " + pageName;
		File file = getFile(pageName);
		if (createdFiles.containsKey(file)) {
			if (!Strings.isBlank(objectCategory)) {
				file = getFile(pageName + " " + objectCategory);
			}
			if (createdFiles.containsKey(file)) {
				throw new IOException("file already exported " + file);
			}
		}

		// create the page and store it
		Page page = new Page();
		createdFiles.put(file, page);

		// write header and return
		PrintStream out = page.printStream;
		if (!suppressExportWarning) {
			out.println(EXPORT_WARNING);
		}
		if (!Strings.isBlank(packageName)) {
			out.println("%%Package " + packageName);
		}
		out.println();
		return out;
	}

	private File getFile(String pageName) throws IOException {
		File file = new File(targetFolder, Strings.encodeURL(pageName) + ".txt");
		return file.getCanonicalFile();
	}

	public void attachFile(File sourceFile, PrintStream out) throws IOException {
		attachFile(sourceFile.getName(), sourceFile, out);
	}

	public void attachFile(String attachmentName, File sourceFile, PrintStream out) throws IOException {
		// first find page object for the specified stream
		for (Map.Entry<File, Page> entry : createdFiles.entrySet()) {
			if (entry.getValue().printStream == out) {
				attachFile(attachmentName, sourceFile, entry.getKey());
				return;
			}
		}
		throw new IOException("The specified PrintStream does not denote a created page");
	}

	private void attachFile(String attachmentName, File sourceFile, File pageFile) throws IOException {
		File folder1 = new File(pageFile.getAbsolutePath().replaceAll("\\.txt$", "-att"));
		File folder2 = new File(folder1, Strings.encodeURL(attachmentName) + "-dir");
		String extension = Files.getExtension(attachmentName);
		File lastExistingFile = null;
		for (int index = 1; ; index++) {
			// check if the target file already exists
			File targetFile = new File(folder2, index + "." + extension);
			if (targetFile.exists()) {
				lastExistingFile = targetFile;
				continue;
			}

			// if not we have found a free file index
			// first check is the last version of the file is identical to our file
			if (lastExistingFile != null) {
				// if both files are identical, no attaching is required
				if (Files.hasEqualFingerprint(lastExistingFile, sourceFile)) {
					break;
				}
			}

			// if not, we should attach the file by coping it to the target file
			Files.copy(sourceFile, targetFile);
			targetFile.setLastModified(sourceFile.lastModified());

			// add line to attachment properties
			Properties props = new Properties();
			File propsFile = new File(folder2, "attachment.properties");
			// load existing file is exists
			if (propsFile.exists()) {
				FileReader reader = new FileReader(propsFile);
				try {
					props.load(reader);
				}
				finally {
					reader.close();
				}
			}
			// and add line and write it back
			props.setProperty(index + ".author", "Wiki Exporter");
			FileWriter out = new FileWriter(propsFile);
			try {
				props.store(out, "Attachment properties modified by Wiki Exporter");
			}
			finally {
				out.close();
			}
			break;
		}
	}

	/**
	 * Returns all the files that have been created by this creator, regardless if they have changed
	 * contents or not (compared to some already existing file in the target folder).
	 *
	 * @return the pages created
	 */
	public Set<File> getCreatedFiles() {
		return Collections.unmodifiableSet(createdFiles.keySet());
	}

	/**
	 * Writes all changed files to the disc and returns the number of changed files.
	 *
	 * @return the number of files written
	 * @throws IOException
	 */
	public int writeFiles() throws IOException {
		ProgressListener progress = new ConsoleProgressBarListener();
		progress.updateProgress(0f, "write wiki files to disc");
		int written = 0;
		int index = 0;
		float total = createdFiles.size();
		for (File file : createdFiles.keySet()) {
			progress.updateProgress(index++ / total, "write wiki files to disc");
			Page page = createdFiles.get(file);
			if (page.write(file)) written++;
		}
		progress.updateProgress(1f, "done");
		return written;
	}
}
