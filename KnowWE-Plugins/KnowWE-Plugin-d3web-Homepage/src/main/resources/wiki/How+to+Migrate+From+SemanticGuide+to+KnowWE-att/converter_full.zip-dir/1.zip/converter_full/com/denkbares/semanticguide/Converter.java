package com.denkbares.semanticguide;/*
 * Copyright (C) 2013 denkbares GmbH
 *
 * This is free software; you can redistribute it and/or modify it under the
 * terms of the GNU Lesser General Public License as published by the Free
 * Software Foundation; either version 3 of the License, or (at your option) any
 * later version.
 *
 * This software is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
 * FOR A PARTICULAR PURPOSE. See the GNU Lesser General Public License for more
 * details.
 *
 * You should have received a copy of the GNU Lesser General Public License
 * along with this software; if not, write to the Free Software Foundation,
 * Inc., 51 Franklin St, Fifth Floor, Boston, MA 02110-1301 USA, or see the FSF
 * site: http://www.fsf.org.
 */

import java.awt.*;
import java.io.File;
import java.io.IOException;
import java.io.PrintStream;
import java.text.DateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collection;
import java.util.Collections;
import java.util.Comparator;
import java.util.Date;
import java.util.HashMap;
import java.util.HashSet;
import java.util.LinkedHashSet;
import java.util.LinkedList;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Set;
import java.util.TreeSet;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import de.d3web.collections.DefaultMultiMap;
import de.d3web.collections.MultiMap;
import de.d3web.collections.MultiMaps;
import de.d3web.core.io.progress.ConsoleProgressBarListener;
import de.d3web.core.io.progress.ProgressListener;
import de.d3web.strings.Strings;
import de.d3web.utils.Files;
import de.knowwe.export.PageCreator;
import de.knowwe.export.TurtleWriter;
import de.knowwe.export.TurtleWriter.Text;

import static com.denkbares.semanticguide.DomainParser.Instance;

/**
 * @author Volker Belli (denkbares GmbH)
 * @created 01.07.14.
 */
public class Converter {

	private final DomainParser parser;
	private final PageCreator pageCreator;
	private final File imagesFolder;

	/**
	 * Store the exported flowchart root nodes with the flowchart names and reveal the exported
	 * flowcharts if the same node is repeatedly exported.
	 */
	private final Map<Instance, String> exportedRootNodes = new HashMap<>();

	public Converter(DomainParser parser, File imagesFolder, File targetFolder) {
		this.parser = parser;
		this.pageCreator = new PageCreator(targetFolder);
		this.imagesFolder = imagesFolder;
	}

	public static void main(String[] args) throws IOException {
		// infect std-outs
		StreamCollector collector = new StreamCollector();
		collector.infectStdOut();

		if (args.length != 1 || Strings.isBlank(args[0])) {
			System.err.println("usage: java Converter <kb-root-folder>");
			System.exit(1);
		}

		// base files: change for your appropriate needs
		File semanticGuideKB = new File(args[0]);

		// prepare source files
		File source = new File(semanticGuideKB, "Semantic Guide/ontologies/domainlayer-sgversion.obl");
		DomainParser parser = new DomainParser(source);
		parser.addPositions(new File(semanticGuideKB, "node_positions.txt"));
		parser.addNames(new File(semanticGuideKB, "subdiagnoses_names.txt"));
		File imagesFolder = new File(semanticGuideKB, "Semantic Guide/data/files/sgversion");

		// create converter
		File targetFolder = new File("/Users/volker_belli/Downloads/wiki-avl-2014-08-11");
		Converter converter = new Converter(parser, imagesFolder, targetFolder);
		converter.addAdditionalValues(new File(semanticGuideKB, "additional_attributes.txt"));

		// and convert
		converter.printLongTermNames();
//		converter.exportTurtle(System.out);
		converter.exportSymptoms();
		converter.exportNamedObjects();

		collector.writeWikiPage(converter.pageCreator.createPage("Export Output"));
		converter.pageCreator.writeFiles();
	}

	private void printLongTermNames() {
		StringBuilder text = new StringBuilder();
		int count = 0;
		for (Instance instance : parser.getInstances()) {
			if (instance.getType().equalsIgnoreCase("Question")
					|| instance.getType().equalsIgnoreCase("Solution")) {
				String name = toShortName(instance);
				if (name.length() > 50) {
					count++;
					text.append("  * ").append(instance.getUri())
							.append(" --> ").append(name).append("\n");
				}
			}
		}
		System.out.println(String.format("\nInstances with long term names: %d \n%s\n",
				count, text));
	}

	@SuppressWarnings("UnusedDeclaration")
	private void exportTurtle(PrintStream out) {
		TurtleWriter writer = new TurtleWriter(out, "rdfs:type");
		for (Instance object : parser.getInstances()) {
			writer.define(object.getUri(), object.getType());
			MultiMap<String, Object> attributes = object.getAttributes();
			for (String attr : attributes.keySet()) {
				Collection<Object> values = normalizeTextLanguages(attributes.getValues(attr));
				writer.relations(attr, values);
			}
		}
		writer.close();
	}

	/**
	 * Returns a single text value if all values are language-tagged texts and all are identical.
	 * Otherwise it leaves the values untouched and returns the original set of values.
	 *
	 * @param values the values to be normalized
	 * @return the normalized values
	 */
	private static Collection<Object> normalizeTextLanguages(Collection<Object> values) {
		String reference = null;
		for (Object value : values) {
			if (value instanceof Text) {
				String ref = ((Text) value).getText();
				if (reference == null || reference.equals(ref)) {
					reference = ref;
					continue;
				}
			}
			return values;
		}
		return Arrays.<Object>asList(new Text(reference));
	}

	private void exportSymptoms() throws IOException {
		// find relevant instance
		Collection<Instance> instances = new LinkedList<>();
		for (Instance instance : parser.getInstances()) {
			if (instance.getType().equals("Symptom")) {
				instances.add(instance);
			}
		}

		int pos = 0;
		Set<String> malfunctions = new TreeSet<>();
		for (Instance instance : instances) {
			String name = instance.getPrefLabel();
			System.out.printf("Export malfunction '%s' (%s of %s)%n", name, ++pos, instances.size());
			exportSymptom(instance);
			malfunctions.add(name);
		}

		exportMainPage("SemanticGuide-Export");
		exportMalfunctionPage(malfunctions);
		exportLeftMenu(malfunctions);
	}

	private void exportMainPage(String kbName) throws IOException {
		PrintStream main = pageCreator.createPage("Main");
		main.println("!!! Knowledge Base\n");
		main.println("This knowledge base has been exported from a Semantic Guide database. " +
				"Due to the different flowchart philosophy, there might be some inconvenience in " +
				"the layout of the particular diagnostic flowcharts. Nevertheless, the main " +
				"functionality of the knowledge base shall be identical. If not, please contact " +
				"[denkbares GmbH|mailto:info@denkbares.com] " +
				"to report the issue.\n");
		main.println("%%KnowledgeBase\n" +
				"  " + kbName + "\n" +
				"  @diaflux-PotentialSolutions: suggest\n" +
				"%\n");
		main.println("%%ShowSolutions\n" +
				"  @show_suggested: TRUE\n" +
				"%\n");

		main.println("\n!!! Basic Statistics\n");
		main.println("%%Include\n" +
				"- [Statistics#Summary]\n" +
				"%\n\n");

		main.println("\n(c) denkbares GmbH, " +
				DateFormat.getDateInstance(DateFormat.SHORT, Locale.getDefault()).format(
						new Date()));
	}

	private void exportLeftMenu(Set<String> malfunctions) throws IOException {
		PrintStream main = pageCreator.createPage("LeftMenu", true);

		main.print("%%CIDaemon\n" +
				"__[Home|Main]__\n" +
				"@dashboardArticle: Continuous Integration\n" +
				"@name: Continuous Integration\n" +
				"%\n\n" +
				"%%CIDaemon\n" +
				"__[Analyse Anomalies | Continuous Integration#Analysis of Knowledge Base Anomalies]__\n" +
				"@dashboardArticle: Continuous Integration\n" +
				"@name: Analyse Anomalies\n" +
				"%\n" +
				"* [Knowledge Base Statistics | Statistics]\n" +
				"* [Query to Detect Anomalies | Query Anomalies]\n" +
				"\n" +
				"__[Malfunctions]__\n");

		for (String malfunction : malfunctions) {
			main.print("* %%(text-overflow:ellipsis;white-space:nowrap;) [" +
					toArticleName(malfunction) + "] /%\n");
		}

		main.print("\n\n" +
				"__[Documentation| Doc Overview]__ / __[FAQ|Doc FAQ]__\n\n" +
				"__Administration__\n\n" +
				"* [Search Object | Lookup Object Info]\n" +
				"* [All pages | PageIndex]\n" +
				"* [Recent Changes |RecentChanges]\n" +
				"* [Plugins | InstalledTagHandlers]\n" +
				"* [Left Menu | LeftMenu]\n" +
				"\n\n" +
				"----\n" +
				"\n" +
				"[{KnowWEPlugin version}]\n");
	}

	private void exportMalfunctionPage(Set<String> malfunctions) throws IOException {
		StringBuilder flow = new StringBuilder();
		flow.append("\t<node fcid='#node_start'>\n" +
				"\t\t<position left='20' top='20'></position>\n" +
				"\t\t<start>Start</start>\n" +
				"\t</node>\n\n");
		flow.append("\t<node fcid='#node_ask'>\n" +
				"\t\t<position left='150' top='20'></position>\n" +
				"\t\t<action markup='KnOffice'><![CDATA[Fehlerbild]]></action>\n" +
				"\t</node>\n");
		flow.append("\t<edge fcid='#rule_start'>\n" +
				"\t\t<origin>#node_start</origin>\n" +
				"\t\t<target>#node_ask</target>\n" +
				"\t</edge>\n");

		int vpos = 20, id = 1;
		for (String malfunction : malfunctions) {
			flow.append("\t<node fcid='#node_").append(id).append("'>\n")
					.append("\t\t<position left='600' top='").append(vpos).append("'></position>\n")
					.append("\t\t<action markup='KnOffice'>")
					.append("<![CDATA[CALL[").append(Strings.quote(malfunction))
					.append("(start)]]]></action>\n")
					.append("\t</node>\n");
			flow.append("\t<edge fcid='#rule_").append(id).append("'>\n")
					.append("\t\t<origin>#node_ask</origin>\n")
					.append("\t\t<target>#node_").append(id).append("</target>\n")
					.append("\t\t<guard markup=\"KnOffice\">")
					.append("<![CDATA[\"Fehlerbild\" = ").append(Strings.quote(malfunction))
					.append("]]></guard>\n")
					.append("\t\t<routingPoint x='").append(0.8 - 0.01 * id).append("' y='1' />\n")
					.append("\t</edge>\n");
			id++;
			vpos += 60;
			if (malfunction.length() > 65) vpos += 20;
		}

		PrintStream main = pageCreator.createPage("Malfunctions");
		main.println("%%DiaFlux\n" +
				"<flowchart fcid='flow_ab99c396' name='Malfunction Selection' " +
				"icon='sanduhr.gif' width='750' height='" + vpos + "' " +
				"autostart='true' idCounter='" + id + "'>\n\n");
		main.println(flow);
		main.println("\n</flowchart>\n%\n");

		main.println("%%Question");
		main.println("Startfragebogen #1");
		main.println("- Fehlerbild [oc]");
		for (String malfunction : malfunctions) {
			main.println("-- " + Strings.quote(malfunction));
		}
		main.println("%");
	}

	private void exportNamedObjects() throws IOException {

		ProgressListener progress = new ConsoleProgressBarListener();
		int pos = 0;

		// find exported named objects
		Collection<Instance> instances = parser.getInstances();
		for (Instance instance : instances) {
			progress.updateProgress((pos++) / (float) instances.size(), "create object pages");
			if (instance.getType().equalsIgnoreCase("Question")) {
				PrintStream out = pageCreator.createPage(toArticleName(instance), "Question");
				exportQuestion(out, null /*"Questions"*/, Arrays.asList(instance));
			}
			if (instance.getType().equalsIgnoreCase("Solution")) {
				PrintStream out = pageCreator.createPage(toArticleName(instance), "Solution");
				exportSolution(out, null /*"Solutions"*/, Arrays.asList(instance));
			}
		}
		progress.updateProgress(1f, "create object pages");
	}

	private void exportSymptom(Instance symptom) throws IOException {
		String name = symptom.getPrefLabel();
		Instance rootNode = (Instance) symptom.getValue("AssignedRootNode");
		exportFlow(name, symptom, rootNode);
	}

	private void exportFlow(String name, Instance instance, Instance callingNode) throws IOException {
		// do not export flowchart twice
		if (exportedRootNodes.containsKey(callingNode)) {
			String sameFlow = exportedRootNodes.get(callingNode);
			if (name.equalsIgnoreCase(sameFlow)) return;

			// if the flow should be exported for a different flowchart name
			// export mini-flowchart that only references the original one
			PrintStream out = pageCreator.createPage(toArticleName(name), "Fehlerbild");
			exportMinimizedFlow(out, name, instance, sameFlow);
			return;
		}
		exportedRootNodes.put(callingNode, name);

		// export the DiaFlux chart
		PrintStream out = pageCreator.createPage(toArticleName(name), "Fehlerbild");
		Collection<Instance> nodes = exportDiaFlux(out, name, instance, callingNode);

		// export sub flows
		for (Instance node : nodes) {
			Instance subFlow = getAssignedSubdiagnosis(node);
			if (subFlow == null) continue;
			// do not export if the sub-flow node also has a symptom,
			// because in this case we export the symptom instead
			Set<Instance> symptoms = reverseLookup("Symptom", "AssignedRootNode", node);
			if (symptoms.size() > 0) continue;
			// otherwise export the sub-flow
			exportFlow(subFlow.getPrefLabelOrUri(), subFlow, node);
		}
	}

	private void exportMinimizedFlow(PrintStream out, String name, Instance symptom, String toFlow) {
		out.println("%%DiaFlux");
		out.printf("<flowchart fcid=%s name=%s width='400' height='100' autostart='false' idCounter='100'>\n",
				Strings.quote(symptom.getUri()), Strings.quote(name));

		// start node
		out.print("\t<node fcid='#node_start'>\n");
		out.print("\t\t<position left='20' top='20'></position>\n");
		out.print("\t\t<start>start</start>\n");
		out.print("\t</node>\n\n");

		// end node
		out.print("\t<node fcid='#node_subflow'>\n");
		out.print("\t\t<position left='220' top='20'></position>\n");
		out.printf("\t\t<action markup='KnOffice'><![CDATA[CALL[%s(start)]]]></action>\n",
				Strings.quote(toFlow));
		out.print("\t</node>\n\n");

		// edge from start to end node
		out.print("\t<edge fcid='#edge_subflow'>\n");
		out.print("\t\t<origin>#node_start</origin>\n");
		out.print("\t\t<target>#node_subflow</target>\n");
		out.print("\t</edge>\n\n");

		out.print("</flowchart>\n");
		out.print("%\n\n");
	}

	/**
	 * Exports a specified flow and returns the instances of all nodes that have been exported to
	 * the flowchart.
	 *
	 * @param out the target stream to export to
	 * @param name the name of the flowchart
	 * @param symptom the flows instance
	 * @param callingNode the root node of the flow
	 * @return the node instances that have been exported
	 */
	private Collection<Instance> exportDiaFlux(PrintStream out, String name, Instance symptom, Instance callingNode) {
		Set<Instance> flowNodes = getFlowNodes(callingNode);
		Rectangle bounds = getBounds(flowNodes);

		out.println("%%DiaFlux");
		out.printf("<flowchart fcid=%s name=%s width='%d' height='%d' autostart='false' idCounter='100'>%n",
				Strings.quote(symptom.getUri()), Strings.quote(name),
				bounds.width, bounds.height);

		for (Instance node : flowNodes) {
			// estimate coordinates
			Point position = getNodePosition(flowNodes, node, bounds);

			// export the selected node
			out.printf("\t<node fcid='%s'>%n", node.getUri());
			out.printf("\t\t<position left='%d' top='%d'></position>%n",
					position.x - bounds.x, position.y - bounds.y);
			if (node == callingNode) {
				out.println("\t\t<start>start</start>");
			}
			Instance question = getAssignedQuestion(node);
			if (question != null) {
				String qname = toShortName(question);
				out.printf("\t\t<action markup='KnOffice'><![CDATA[%s]]></action>%n", Strings.quote(qname));
			}
			Instance solution = getAssignedSolution(node);
			if (solution != null) {
				String sname = toShortName(solution);
				out.printf("\t\t<action markup='KnOffice'><![CDATA[%s = P7]]></action>%n", Strings.quote(sname));
			}
			Instance subFlow = getAssignedSubdiagnosis(node);
			boolean isFlowCall = subFlow != null && node != callingNode;
			if (isFlowCall) {
				String subFlowName = subFlow.getPrefLabelOrUri();
				// check if the subflow has a root node that is also the root node of a symptom
				Set<Instance> symptoms = reverseLookup("Symptom", "AssignedRootNode", node);
				if (symptoms.size() > 0) {
					subFlowName = symptoms.iterator().next().getPrefLabel();
				}
				out.printf("\t\t<action markup='KnOffice'><![CDATA[CALL[%s(start)]]]></action>%n",
						Strings.quote(subFlowName));
			}
			out.println("\t</node>\n");

			// add edges if we are not calling a subflow
			if (!isFlowCall) {
				Set<Instance> answers = getDecisionAlternatives(node);
				for (Instance answer : answers) {
					Instance target = getNextDecisionNode(answer);
					out.printf("\t<edge fcid=%s>%n", Strings.quote(answer.getUri()));
					out.printf("\t\t<origin>%s</origin>%n", node.getUri());
					out.printf("\t\t<target>%s</target>%n", target.getUri());
					// add guard if question is referenced and more than one value is available
					if (question != null /*&& answers.size() > 1*/) {
						out.printf("\t\t<guard markup='KnOffice'><![CDATA[%s]]></guard>%n",
								getCondition(question, answer));
					}
					out.println("\t</edge>\n");
				}
			}
		}

		out.println("</flowchart>");
		out.println("%");

		return flowNodes;
	}

	private Point getNodePosition(Set<Instance> flowNodes, Instance node, Rectangle bounds) {
		Point position = getClosestPosition(flowNodes, node);
		if (position == null) {
			position = getEstimatedPosition(flowNodes, node, bounds);
		}
		if (position == null) {
			System.err.println("No position for node " + node.getUri());
			position = new Point(10, 10);
		}
		return position;
	}

	private Point getClosestPosition(Set<Instance> flowNodes, Instance node) {
		Collection<Point> positionHints = node.getValues("position", Point.class);
		if (positionHints.isEmpty()) return null;
		if (positionHints.size() == 1) return positionHints.iterator().next();

		Set<Instance> previousNodes = getPreviousNodes(node);
		List<Point> previousPositions = new LinkedList<>();
		for (Instance previousNode : previousNodes) {
			Point position = getNodePosition(flowNodes, previousNode, null);
			previousPositions.add(position);
		}

		Point bestPosition = null;
		float bestDistance = Float.MAX_VALUE;
		for (Point position : positionHints) {
			// calculate best distance to previous nodes
			float distance = Float.MAX_VALUE;
			for (Point prev : previousPositions) {
				int dx = prev.x - position.x, dy = prev.y - position.y;
				float dist = (float) Math.sqrt(dx * dx + dy * dy);
				distance = Math.min(distance, dist);
			}
			// optimize position to best one
			if (bestPosition == null || distance < bestDistance) {
				bestPosition = position;
				bestDistance = distance;
			}
		}
		return bestPosition;
	}

	private Point getEstimatedPosition(Set<Instance> flowNodes, Instance node, Rectangle bounds) {
		// get all nodes linked to this node
		Set<Instance> linkedNodes = new LinkedHashSet<>();
		// add all nodes that are referenced by this node
		for (Instance answer : getDecisionAlternatives(node)) {
			Instance linkedNode = getNextDecisionNode(answer);
			if (flowNodes.contains(linkedNode)) {
				linkedNodes.add(linkedNode);
			}
		}
		// add all nodes of this flow that references this node
		for (Instance prevNode : flowNodes) {
			for (Instance answer : getDecisionAlternatives(prevNode)) {
				if (node == getNextDecisionNode(answer)) {
					linkedNodes.add(prevNode);
				}
			}
		}
		// check for the first free position
		for (Instance linkedNode : linkedNodes) {
			Point linkedPosition = (Point) linkedNode.getValue("position");
			if (linkedPosition != null) {
				int x = linkedPosition.x;
				int y = linkedPosition.y;
				if (isFlowPositionFree(flowNodes, bounds, x - 220, y + 10)) {
					return new Point(x - 220, y + 10);
				}
				if (isFlowPositionFree(flowNodes, bounds, x + 220, y + 10)) {
					return new Point(x + 220, y + 10);
				}
			}
		}
		return null;
	}

	private Rectangle getBounds(Collection<Instance> flowNodes) {
		Rectangle bounds = new Rectangle();
		for (Instance node : flowNodes) {
			@SuppressWarnings("unchecked")
			Point position = (Point) node.getValue("position");
			if (position != null) {
				bounds.add(position.x - 10, position.y - 10);
				bounds.add(position.x + 220, position.y + 70);
			}
		}
		return bounds;
	}

	private boolean isFlowPositionFree(Collection<Instance> flowNodes, Rectangle bounds, int x, int y) {
		if (bounds != null && !bounds.contains(x, y)) return false;
		Rectangle testRect = new Rectangle(x, y, 160, 40);
		for (Instance node : flowNodes) {
			Point position = (Point) node.getValue("position");
			if (position != null) {
				Rectangle nodeRect = new Rectangle(position.x, position.y, 160, 40);
				if (nodeRect.intersects(testRect)) return false;
			}
		}
		return true;
	}

	private Set<Instance> getFlowNodes(Instance callingNode) {
		Set<Instance> openNodes = new LinkedHashSet<>(Arrays.asList(callingNode));
		Set<Instance> closedNodes = new HashSet<>();
		while (!openNodes.isEmpty()) {
			// select next node and mode it from open to closed nodes
			Instance node = openNodes.iterator().next();
			openNodes.remove(node);
			closedNodes.add(node);

			// add next nodes
			Instance subFlow = getAssignedSubdiagnosis(node);
			boolean isFlowCall = subFlow != null && node != callingNode;
			if (!isFlowCall) {
				for (Instance answer : getDecisionAlternatives(node)) {
					Instance target = getNextDecisionNode(answer);
					// and move the the next nodes to open list
					// if they are not already closed
					if (!closedNodes.contains(target)) {
						openNodes.add(target);
					}
				}
			}
		}
		return closedNodes;
	}

	private String getCondition(Instance question, Instance answer) {
		String choice = getExpectedValue(answer).getPrefLabel();
		Set<String> choices = getAllAlternativeNames(question);
		// map choices if yes/no question
		if (choice.equals("Ja") || choice.equals("Nein")) {
			boolean isYN = choices.size() == 2 && choices.contains("Ja") && choices.contains("Nein");
			if (isYN) {
				choice = choice.equals("Ja") ? "Yes" : "No";
			}
		}
		return Strings.quote(toShortName(question)) + " = " + Strings.quote(choice);
	}

	private Instance getNextDecisionNode(Instance answer) {
		return (Instance) answer.getValue("NextDecisionNode");
	}

	private Instance getAssignedQuestion(Instance node) {
		return (Instance) node.getValue("AssignedQuestion");
	}

	private Instance getAssignedSolution(Instance node) {
		return (Instance) node.getValue("AssignedSolution");
	}

	private Instance getAssignedSubdiagnosis(Instance node) {
		return (Instance) node.getValue("AssignedSubdiagnosis");
	}

	/**
	 * Creates Wiki markup for a question defined by the semantic guide.
	 */
	private void exportQuestion(PrintStream out, String form, Collection<Instance> questions) throws IOException {
		// export question definition
		out.println("%%Question");
		String linePrefix = "";
		if (!Strings.isBlank(form)) {
			out.printf("%s%n", form);
			linePrefix = "- ";
		}
		for (Instance question : questions) {
			String name = toShortName(question);
			Set<String> choices = getAllAlternativeNames(question);
			boolean isYN = choices.size() == 2 && choices.contains("Ja") && choices.contains("Nein");
			out.printf("%s%s [%s]%n", linePrefix, Strings.quote(name), isYN ? "yn" : "oc");
			if (!isYN) {
				for (String choice : choices) {
					out.printf("-%s%s%n", linePrefix, Strings.quote(choice));
				}
			}
		}
		out.println("%");
		out.println();

		// export attachments if available
		MultiMap<Instance, String> attachmentsMap = getAttachmentsMap(out, questions);

		// export some properties
		out.println("%%Property");
		for (Instance question : questions) {
			printPlainProperty(out, question, "cost", "cost");
			printTextProperty(out, question, "HasQuestionText", "prompt");
			out.println();
			printTextProperty(out, question, "documentation", "description");
			out.println();
			printLinkProperty(out, question, attachmentsMap);
		}
		out.println("%");
	}

	private MultiMap<Instance, String> getAttachmentsMap(PrintStream out, Collection<Instance> questionsOrSolutions) throws IOException {
		MultiMap<Instance, String> attachmentsMap = new DefaultMultiMap<>(
				MultiMaps.<Instance>linkedFactory(), MultiMaps.<String>linkedFactory());
		for (Instance question : questionsOrSolutions) {
			Collection<Instance> attachments = question.getValues("HasAttachment", Instance.class);
			for (Instance attachment : attachments) {
				Text exportName = (Text) attachment.getValue("ExportName");
				if (exportName == null) continue;
				Text imageName = (Text) attachment.getValue("ImportName");
				if (imageName == null) continue;
				String image = toArticleName(imageName.getText());
				out.printf("[{Image src='%s' width='200' align='left'}]\n", image);
				out.printf("%%%%Resource%n@src=%s%n@path=%s%n%%%n%n", image, image);
				attachmentsMap.put(question, image);
				File sourceFile = new File(imagesFolder, exportName.getText());
				pageCreator.attachFile(image, sourceFile, out);
			}
		}
		return attachmentsMap;
	}

	private void printLinkProperty(PrintStream out, Instance question, MultiMap<Instance, String> attachmentsMap) {
		Set<String> images = attachmentsMap.getValues(question);
		if (images.isEmpty()) return;
		out.printf("%s.%s=%s%n",
				Strings.quote(toShortName(question)), "link",
				Strings.quote(Strings.concat(";", images)));
	}

	private void printPlainProperty(PrintStream out, Instance question, String predicateName, String propertyName) {
		String name = toShortName(question);
		for (Object value : question.getValues(predicateName)) {
			out.printf("%s.%s=%s", Strings.quote(name), propertyName, value);
			out.println();
		}
	}

	private void printTextProperty(PrintStream out, Instance question, String predicateName, String propertyName) {
		String name = toShortName(question);
		Collection<Object> values = question.getValues(predicateName);
		if (values.isEmpty()) return;

		// first check if all names are the same, then only use the generic form
		List<Text> texts = new ArrayList<>();
		boolean allSame = true;
		String lastText = null;
		for (Object value : values) {
			Text text = (Text) value;
			texts.add(text);
			String thisText = text.getText();
			if (lastText != null && !lastText.equalsIgnoreCase(thisText)) {
				allSame = false;
			}
			lastText = thisText;
		}

		if (allSame) {
			// if all texts are same, we use only one text without a locale
			texts.clear();
			texts.add(new Text(lastText));
		}
		else {
			// otherwise we sort the texts by locale to provide stable orders
			Collections.sort(texts, new Comparator<Text>() {
				@Override
				public int compare(Text t1, Text t2) {
					Locale l1 = t1.getLocale();
					Locale l2 = t2.getLocale();
					if (l1 == l2) return 0;
					if (l1 == null) return -1;
					if (l2 == null) return 1;
					return l1.toString().compareTo(l2.toString());
				}
			});
		}

		for (Text text : texts) {
			// quote text as appropriate for properties
			// with triple quotes if it contains return characters
			String string = text.getText();
			if (string.contains("\r") || string.contains("\n")) {
				string = "\"\"\"" + string + "\"\"\"";
			}
			else {
				string = Strings.quote(string);
			}
			out.printf("%s.%s%s=%s", Strings.quote(name), propertyName,
					text.hasLocale() ? "." + text.getLocale() : "", string);
			out.println();
		}
	}

	/**
	 * Creates Wiki markup for a question defined by the semantic guide.
	 */
	private void exportSolution(PrintStream out, String group, Collection<Instance> solutions) throws IOException {
		out.println("%%Solution");
		String linePrefix = "";
		if (!Strings.isBlank(group)) {
			out.printf("%s%n", group);
			linePrefix = "- ";
		}
		for (Instance solution : solutions) {
			String name = toShortName(solution);
			out.printf("%s%s%n", linePrefix, Strings.quote(name));
		}
		out.println("%");
		out.println();

		// export attachments if available
		MultiMap<Instance, String> attachmentsMap = getAttachmentsMap(out, solutions);

		// export some properties
		out.println("%%Property");
		for (Instance solution : solutions) {
			printTextProperty(out, solution, "HasAction", "prompt");
			out.println();
			printTextProperty(out, solution, "HasCause", "description");
			out.println();
			printLinkProperty(out, solution, attachmentsMap);
		}
		out.println("%");
	}

	private String toArticleName(String pageName) {
		return pageName.replaceAll("[?'°\"]+", "").replaceAll("\\s*[\\\\/]+\\s*", "-")
				.replace(":", "");
	}

	private String toArticleName(Instance questionOrSolution) {
		return toArticleName(toShortName(questionOrSolution));
	}

	private String toShortName(Instance questionOrSolution) {
		String name = (String) questionOrSolution.getValue("name");
		if (name == null) {
			Text questionText = (Text) questionOrSolution.getValue("HasQuestionText");
			if (questionText != null) name = questionText.getText();
		}
		if (name == null) {
			String prefLabel = questionOrSolution.getPrefLabel();
			if (prefLabel != null) name = prefLabel;
		}
		if (name == null) name = questionOrSolution.getUri();
		return name.replace('\n', ' ').replace('\r', ' ').replace('\t', ' ')
				.replace('\b', ' ').replace('\f', ' ');
	}

	private void addAdditionalValues(File file) throws IOException {
		String objectRegex = null;
		Pattern assignPattern = Pattern.compile("^\\.([\\w:-_]+)\\s*=\\s*(.*)$");

		Map<Instance, String> originalNames = new HashMap<>();
		for (Instance instance : parser.getInstances()) {
			originalNames.put(instance, toShortName(instance));
		}

		System.out.println("Add attributes defined in file " + file);
		List<String> lines = Files.getLines(file);
		for (String line : lines) {
			line = Strings.trim(line);
			if (line.isEmpty()) continue;
			if (line.startsWith("//")) {
				System.out.println("  " + line);
				continue;
			}
			Matcher assign = assignPattern.matcher(line);
			if (assign.matches()) {
				// set an attribute to the objects
				String attribute = assign.group(1);
				String value = assign.group(2);
				int matches = addAdditionalValue(originalNames, objectRegex, attribute, value);
				if (matches == 0) {
					System.err.println(String.format(
							"Warning: Could not set attribute '%s', because expression '%s' not matched any instances",
							attribute, objectRegex));
				}
				else {
					System.out.println(String.format("  * applied '.%s = %s' to %d instances matching %s",
							attribute, value, matches, objectRegex));
				}
			}
			else {
				// instance if referenced
				objectRegex = line;
			}
		}
	}

	private static int addAdditionalValue(Map<Instance, String> originalNames, String objectRegex, String attribute, String valueTemplate) {
		int count = 0;
		for (Instance instance : originalNames.keySet()) {
			String name = instance.getType() + ":" + originalNames.get(instance);

			// if name matches
			Matcher matcher = Pattern.compile(objectRegex).matcher(name);
			if (matcher.matches()) {

				// replace all placeholders in the value
				String id = instance.getUri().replaceAll("^.*_(\\w*)$", "$1");
				String value = valueTemplate.replace("$id", id);
				for (int i = 1; i <= matcher.groupCount(); i++) {
					String group = matcher.group(i);
					if (group == null) group = "";
					value = value.replace("$" + i, group);
				}

				// and set the attribute
				// if the attribute not already exists
				if (instance.getValue(attribute) == null) {
					instance.addValue(attribute, value);
					count++;
				}
			}
		}
		return count;
	}

	private Set<String> getAllAlternativeNames(Instance question) {
		Set<String> result = new TreeSet<>();
		for (Instance answer : getAllAlternatives(question)) {
			String text = answer.getPrefLabel();
			result.add(text);
		}
		return result;
	}

	private Set<Instance> getAllAlternatives(Instance question) {
		Set<Instance> result = new HashSet<>();
		Set<Instance> nodes = getDecisionNodes(question);
		for (Instance node : nodes) {
			Set<Instance> answers = getDecisionAlternatives(node);
			for (Instance answer : answers) {
				result.add(getExpectedValue(answer));
			}
		}
		return result;
	}

	private Set<Instance> getDecisionNodes(Instance question) {
		return reverseLookup("DecisionNode", "AssignedQuestion", question);
	}

	private Set<Instance> getPreviousNodes(Instance node) {
		Set<Instance> result = new HashSet<>();
		for (Instance previousNode : parser.getInstances()) {
			if (!"DecisionNode".equals(previousNode.getType())) continue;
			Set<Instance> alternatives = getDecisionAlternatives(previousNode);
			for (Instance alternative : alternatives) {
				if (node.equals(getNextDecisionNode(alternative))) {
					result.add(previousNode);
					break;
				}
			}
		}
		return result;
	}

	/**
	 * Returns all instances of a specified type that reference the specified instance by the
	 * specified attribute.
	 *
	 * @param type the type of the objects to be found
	 * @param attribute the attribute to reference the object by
	 * @param object the instance to be referenced by the attribute
	 * @return all instances of the specified type that references the specified object by the
	 * specified attribute
	 */
	private Set<Instance> reverseLookup(String type, String attribute, Object object) {
		Set<Instance> result = new HashSet<>();
		for (Instance instance : parser.getInstances()) {
			if (instance.getType().equals(type)) {
				Collection<Object> values = instance.getValues(attribute);
				if (values != null && values.contains(object)) {
					result.add(instance);
				}
			}
		}
		return result;
	}

	private Set<Instance> getDecisionAlternatives(Instance node) {
		return toInstances(node.getValues("HasDecisionAlternatives"));
	}

	private Instance getExpectedValue(Instance answer) {
		return (Instance) answer.getValue("HasExpectedValue");
	}

	private static Set<Instance> toInstances(Collection<Object> values) {
		Set<Instance> result = new HashSet<>();
		for (Object value : values) {
			result.add((Instance) value);
		}
		return result;
	}
}
