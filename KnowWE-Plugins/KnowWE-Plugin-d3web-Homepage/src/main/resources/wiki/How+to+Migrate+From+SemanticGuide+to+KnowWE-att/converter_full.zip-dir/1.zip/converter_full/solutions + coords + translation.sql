SELECT 
	[sgdesigner].[dbo].[solution].id AS solution_id,
	[sgdesigner].[dbo].[node_position].x_coord, [sgdesigner].[dbo].[node_position].y_coord,
	[sgdesigner].[dbo].[translation].value0
 FROM [sgdesigner].[dbo].[solution]
	JOIN [sgdesigner].[dbo].[node_position]	
	ON [sgdesigner].[dbo].[node_position].solution_id = [sgdesigner].[dbo].[solution].id
	JOIN [sgdesigner].[dbo].[translation]
	ON [sgdesigner].[dbo].[translation].id = [sgdesigner].[dbo].[solution].NAME_TRANSLATION_ID
ORDER BY [sgdesigner].[dbo].[solution].id ASC